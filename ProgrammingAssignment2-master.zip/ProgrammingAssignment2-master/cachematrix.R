# This program is written to save computation
# overheads during computation of inverse of a matrix.
# For this purpose we use the caching of the matrix and it's inverse.
# We reuse the cached matrix post a matrix inversion 
# calculation avoiding redundant calculations.
 

#This function creates an object of the special 'matrix' 
#that can cache its inverse and returns a list of functions to save 
#and retrieve cached matrices.

makeCacheMatrix <- function(x = matrix()) {
        inv_mat_cached <- NULL
        set_in_cache <- function(y) {
                x <<- y
                inv_mat_cached <<- NULL
        }
        get_from_cache <- function() x
        setInverse <- function(inverse) inv_mat_cached <<- inverse
        getInverse <- function() inv_mat_cached
        list(set = set_in_cache,
             get = get_from_cache,
             setInverse = setInverse,
             getInverse = getInverse)
}
# This function calculates the inverse of the special 'matrix' 
# using the object returned from the makeCacheMatrix function.
# If theres already a pre computed inverse in the cache, this 
# function simply prints the cached inverse matrix
  
cacheSolve <- function(x, ...) {
        inv_from_cached <- x$getInverse()
        if (!is.null(inv_from_cached)) {
                message("getting cached data")
                return(inv_from_cached)
        }
        mat <- x$get()
        inv_from_cached <- solve(mat, ...)
        x$setInverse(inv_from_cached)
        inv_from_cached
}